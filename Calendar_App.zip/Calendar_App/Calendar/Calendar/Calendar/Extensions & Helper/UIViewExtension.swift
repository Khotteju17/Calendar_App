//
//  UIViewExtension.swift
//  CalendarControll
//
//  Created by Tejashree on 30/06/23.
//

import UIKit

// MARK: - UIView extension

extension UIView {
    
    /// Set view rounded
    func ssSetRounded() {
        layer.cornerRadius = bounds.height/2
    }
    
}
