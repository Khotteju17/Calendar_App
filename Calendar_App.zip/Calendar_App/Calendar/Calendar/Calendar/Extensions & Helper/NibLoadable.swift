//
//  AppDelegate.swift
//  TransitionWithCell
//
//  Created by Tejashree on 30/06/23.
//

import UIKit

/// Helper protocol for load view from nib
protocol NibLoadable where Self: UIView {
    func ssFromNib() -> UIView?
}

// MARK: - Nib extension

extension NibLoadable {
    @discardableResult
    func ssFromNib() -> UIView? {
        let bundle = Bundle(for: type(of: self))
        let contentView = bundle.loadNibNamed(String(describing: type(of: self)), owner: self, options: nil)?.first as? UIView ?? UIView()
        self.addSubview(contentView)
        contentView.translatesAutoresizingMaskIntoConstraints = false
        contentView.setConstraints(to: self)
        return contentView
    }
}
