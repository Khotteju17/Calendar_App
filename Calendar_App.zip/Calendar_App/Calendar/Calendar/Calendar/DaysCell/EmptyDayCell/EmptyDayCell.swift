//
//  EmptyDayCell.swift
//  CalendarControll
//
//  Created by Tejashree on 30/06/23.
//

import UIKit

class EmptyDayCell: UICollectionViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
